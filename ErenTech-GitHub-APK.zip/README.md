# ErenTech Android APK

Projeto Android pronto para abrir no Android Studio e gerar o APK.

## Configuração
- App: ErenTech
- URL: https://erentech.discloud.app/
- Package: com.erentech.app
- Min Android: 6.0 (API 23)
- Target/Compile: API 35

## Gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e instalar os componentes solicitados.
3. Vá em Build > Generate App Bundles or APKs > Generate APKs.
4. O APK de debug será criado em `app/build/outputs/apk/debug/`.

O aplicativo inclui WebView com JavaScript, armazenamento local, seleção de arquivos, downloads/links externos e botão voltar.
