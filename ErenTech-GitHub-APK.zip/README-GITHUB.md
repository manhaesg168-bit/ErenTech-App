# ErenTech — compilação automática

Este projeto pode ser compilado pelo GitHub Actions sem PC/Android Studio local.

## No celular

1. Crie um repositório no GitHub.
2. Envie **todo o conteúdo desta pasta** para a raiz do repositório (não envie a pasta `ErenTech-APK` como uma pasta dentro do repositório).
3. Abra a aba **Actions**.
4. Se aparecer "I understand my workflows, go ahead and enable them", toque para habilitar.
5. Abra **Build ErenTech APK** e toque em **Run workflow**.
6. Aguarde terminar.
7. Abra a execução concluída e, na área **Artifacts**, baixe `ErenTech-APK.zip`.
8. Extraia o ZIP: dentro estará `ErenTech.apk`.

O workflow usa GitHub Actions para configurar Java/Android SDK, executar Gradle e salvar o APK como artifact. O GitHub documenta o uso de Actions para builds com Gradle e artifacts para arquivos gerados por workflows.
